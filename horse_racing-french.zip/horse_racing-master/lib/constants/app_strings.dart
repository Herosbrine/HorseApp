class AppStrings {
  static final String appName = "CHG Racing";
  static final String somethingWrong =
      "Something went wrong. Please try again.";
  static final String resetPasswordEn =
      'Enter your email address and we will send you a link to reset your password.';
  static final String resetPassword =
      'Entrez votre adresse e-mail et nous vous enverrons un lien pour réinitialiser votre mot de passe.';
}
