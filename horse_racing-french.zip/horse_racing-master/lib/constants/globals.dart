class AppGlobals {
  static double screenWidth = 400;
  static double screenHeight = 800;

  static final bool isEnglish = false;

  static String? userId;
  static String? email;
  static String? userName;
}
