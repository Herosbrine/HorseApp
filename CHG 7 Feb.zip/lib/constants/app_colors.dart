import 'package:flutter/material.dart';

class AppColors {
  static const Color orange = Color(0xFFFF7E1D);
  static const Color lightGrey = Color(0xFFC2C2CB);
  static const Color grey = Color(0xFF707070);
  static const Color teal = Color(0xFF077F7B);
}
