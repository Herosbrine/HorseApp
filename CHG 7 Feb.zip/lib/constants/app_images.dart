class AppImages {
  static const String logo = 'assets/images/logo.png';
  static const String horse = 'assets/images/horse.jpg';
  static const String horses_bg = 'assets/images/horses_bg.jpg';

  static const String ic_email = 'assets/icons/ic_email.png';
  static const String ic_lock = 'assets/icons/ic_lock.png';
}
