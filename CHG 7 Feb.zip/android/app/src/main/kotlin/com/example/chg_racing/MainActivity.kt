package com.example.chg_racing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
